ABOUT
This ZIP file contains the tawk.to module for joomla versions 2.5.x upto 3.x
-- The tawk.to module will load the tawk.to widget on pages you have assigned the module to display.  

Note: if you want to load the tawk.to widget to all your joomla website pages, use the tawk.to Plugin

NSTALLATION
1. Download mod_tawkto.zip.
2. In the Joomla administration panel, go to: Extensions --> Manage --> Install
3. Select "Upload & Install Joomla Extension", click "Choose file" and select the "mod_tawkto.zip" file to install the module
4. Then click Upload & Install to upload the file and complete the installation
5. for the module settings, in the Joomla administration panel go to: Extensions --> Modules and search for "tawk.to"


Note: Having trouble and need some help? Check out our Knowledge Base at https://www.tawk.to/knowledgebase/
