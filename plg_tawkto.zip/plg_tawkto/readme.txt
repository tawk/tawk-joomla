ABOUT
This ZIP file contains the tawk.to plugin for joomla versions 2.5.x upto 3.x
-- The tawk.to system plugin will load the tawk.to widget in every webpage 

Note: if you want to load the tawk.to widget to specific pages only, use the tawk.to module

NSTALLATION
1. Download plg_tawkto.zip.
2. In the Joomla administration panel, go to: Extensions --> Manage --> Install
3. Select "Upload & Install Joomla Extension", click "Choose file" and select the "plg_tawkto.zip" file to install the plugin
4. Then click Upload & Install to upload the file and complete the installation
5. for the plugin settings, in the Joomla administration panel go to: Extensions --> Plugin and search for "tawk.to"


Note: Having trouble and need some help? Check out our Knowledge Base at https://www.tawk.to/knowledgebase/
